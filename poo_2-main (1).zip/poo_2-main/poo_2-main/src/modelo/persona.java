/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author ERICK
 */
    public class persona {
    private String puesto,codigo,nit,nombres,apellidos,direccion,telefono,fecha_nacimiento;
    
    public persona(){}
    public persona(String nombre, String apellidos, String direccion, String telefono, String fecha_nacimiento,String nit) {
    this.nombres = nombre;
    this.apellidos = apellidos;
    this.direccion = direccion;
    this.telefono = telefono;
    this.fecha_nacimiento = fecha_nacimiento;
    this.nit = nit;
    }
     public persona(String nombre, String apellidos, String direccion, String telefono, String fecha_nacimiento,  String codigo,String total) {
        this.nombres = nombre;
        this.apellidos = apellidos;
        this.direccion = direccion;
        this.telefono = telefono;
        this.fecha_nacimiento = fecha_nacimiento;
        this.codigo = codigo;
        this.puesto = puesto;
        
        }
     
    
    public String getNit() {
        return nit;
    }
    public void setNit(String nit) {
        this.nit = nit;
    }
    public String getNombres() {
        return nombres;
    }
    public void setNombres(String nombres) {
        this.nombres = nombres;
    }
    public String getApellidos() {
        return apellidos;
    }
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
    public String getDireccion() {
        return direccion;
    }
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    public String getTelefono() {
        return telefono;
    }
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    public String getFecha_nacimiento() {
        return fecha_nacimiento;
    }
    public void setFecha_nacimiento(String fecha_nacimiento) {
        this.fecha_nacimiento = fecha_nacimiento;
    }
    protected void agregar(){ } 
    protected void Actualizar(){ }
    protected void eliminar(){ }
    
}
